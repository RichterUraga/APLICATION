//Este es un programa tipo aplicación en el cual estamos usando 3 metodos de las clases anteriores los cuales son el insertion sort, el bubble sort (más ineficiente), y el quick sort.
//Ricardo Uraga de la Fuente A01028921
//Fecha creación : 09/09/2020
#include<iostream>
#include "aplication.h"
#include<vector>
#include<chrono>

using namespace std;
using namespace std::chrono;

int main()
{
    
    int numBusquedas;
    int menu = 0;

    //Creamos nuestro objeto 
    Aplicacion <int> AP;
    //Tamaño del vector
    int count;
    cout << "¿Size off the Array?... " << endl;
    cin >> count;  
    cout << "How many searches do you want to carry out" << endl;
    cin >> numBusquedas;
    //con el valor de count declaramos el numero de enteros o la variable que deseemos para nuestro vector.
    vector <int> elementos; //Vector con el numero de elementos dentro del vector
    for(int i = 0; i < numBusquedas; i++)
    {
        for(size_t i = 0; i < count; i++)
        {
            elementos.push_back(rand()%count);
        }
        cout << "Unsorted" << endl;
        AP.print_vector(elementos, count);
        //Entero que vamos a buscar en el secuencial desordenado y en el binario ordenado.
        int enteroBusqueda;
        cout << "¿Which number do you want to search?" << endl;
        cin >> enteroBusqueda;

        cout << "Index where is the number in the sequential search is this one ....: " << AP.busqSecuencial(enteroBusqueda, elementos) << endl;
        //Aquí termina la busqueda secuencial
        //-----------------------------------
        bool x = true;
        while(x == true)
        {
            cout << "which one is the sorting method you want to implement" << endl;
            cout << "1.Insertion Sort" << endl;
            cout << "2.Bubble Sort" << endl;
            cout << "3.Quick Sort" << endl;
            cin >> menu;
            if(menu > 0 and menu <= 3)
            {
                x = false;
            }
        
        }
        //auto inicio=high_resolution_clock::now();
        if(menu == 1)
        {
            AP.insertionSort(elementos);
        }
        
        if(menu == 2)
        {
            AP.bubbleSort(elementos);      
        }
        
        if(menu == 3)
        {
            AP.quickSort(elementos, 0, elementos.size()-1);
        }
        //auto fin=high_resolution_clock::now();
        //auto time=duration_cast<microseconds>(fin - inicio);
	      //cout<<time<<endl; 
        cout << "sorted" << endl;
        AP.print_vector(elementos, count);
        
        cout << "The number inside the array (index) with binary search is..... " << AP.busqBinaria(enteroBusqueda, elementos, 0, elementos.size()) << endl;
        elementos.clear();
    }
}